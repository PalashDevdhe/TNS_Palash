let player1 = "Player 1";
        let player2 = "Player 2";
        let player3 = "Player 3";
        let player4 = "Player 4";

        let scores = [0, 0, 0, 0];

        function editNames() {
            player1 = prompt("Enter Player 1 name") || "Player 1";
            player2 = prompt("Enter Player 2 name") || "Player 2";
            player3 = prompt("Enter Player 3 name") || "Player 3";
            player4 = prompt("Enter Player 4 name") || "Player 4";

            document.querySelector(".Player1").textContent = player1;
            document.querySelector(".Player2").textContent = player2;
            document.querySelector(".Player3").textContent = player3;
            document.querySelector(".Player4").textContent = player4;
        }

        function rollTheDice() {
            // Play roll sound
            document.getElementById("rollSound").play();

            // Add animation
            for (let i = 1; i <= 4; i++) {
                document.querySelector(`.img${i}`).style.transform = "rotate(360deg)";
            }

            setTimeout(() => {
                let rolls = [];
                for (let i = 0; i < 4; i++) {
                    rolls[i] = Math.floor(Math.random() * 6) + 1;
                    document.querySelector(`.img${i + 1}`).setAttribute("src", `dice${rolls[i]}.png`);
                    document.querySelector(`.img${i + 1}`).style.transform = "rotate(0deg)";
                }

                let maxScore = Math.max(...rolls);
                let winners = [];

                if (rolls[0] === maxScore) winners.push(player1);
                if (rolls[1] === maxScore) winners.push(player2);
                if (rolls[2] === maxScore) winners.push(player3);
                if (rolls[3] === maxScore) winners.push(player4);

                // Update score if only one winner
                if (winners.length === 1) {
                    let index = rolls.indexOf(maxScore);
                    scores[index]++;
                    document.querySelector(`.score${index + 1}`).textContent = scores[index];
                    document.querySelector("h1").innerHTML = `${winners[0]} WINS! 🏆`;
                    document.getElementById("winSound").play();
                } else {
                    document.querySelector("h1").innerHTML = `Draw! 🤝 (${winners.join(" & ")})`;
                }

            }, 1000);
        }

        function resetGame() {
            scores = [0, 0, 0, 0];
            for (let i = 1; i <= 4; i++) {
                document.querySelector(`.score${i}`).textContent = "0";
                document.querySelector(`.img${i}`).setAttribute("src", "dice6.png");
            }
            document.querySelector("h1").innerHTML = "Let's Play";
        }